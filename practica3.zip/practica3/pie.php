	<footer>
		<p>Autor: Efim Ciubuc ©copyright 2019</p>
	</footer>
</body>
</html>
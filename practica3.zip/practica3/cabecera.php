<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title></title>
		<meta name="description" content="Proyecto">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- mi Hoja de estilos -->
		<link rel="stylesheet" type="text/css" href="css/css.css">
		<!-- mi javascript -->
		<script src="js/js.js"></script>
		 	<!-- fontAwesone -->
	    <link rel="stylesheet" href="fontawesome-free-5.11.2-web/css/all.css">
	</head>
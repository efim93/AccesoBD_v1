<?php 
    include_once('bd/AcionesBD.php');

/*objeto de la clace acciones a bases de datos*/
    $o=new AccionesBD();
/*sentencia sql */
$sql="DELETE FROM usuarios WHERE idusuario = ?";
/* array con el id */
$a=array($_GET['id']);
	/**
	 * metodo que nos borra el registo 
	 * @param: $sql,$str,$a:array()
	 */
$result=$o->borrarRegistro($sql,"EMPLEADOS",$a);
/* despues de borrar le redireciono a la pagina principal del back-end */
header('location:admin.php');

 ?>